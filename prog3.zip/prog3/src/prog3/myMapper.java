package prog3;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
 public void map(LongWritable inkey, Text inval, Context context) throws IOException, InterruptedException{
	 String line = inval.toString();
	
		 String[] lineparts2 = line.split(",");
		 String val="4001364";
			 if(lineparts2[2].equalsIgnoreCase(val)){
				 Text mapoutkey = new Text(line);
				 //IntWritable mapoutval = new IntWritable(1);
				 context.write(mapoutkey, null);
		 }
 }
 
}
