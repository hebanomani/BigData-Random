package custRecordReader;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myDriver {
	public static void main(String[] args) 
            throws IOException, ClassNotFoundException, InterruptedException {
		Configuration c = new Configuration();
Job job = new Job(c, "Custom Record Reader");
job.setJarByClass(myDriver.class);
job.setReducerClass(myReducer.class);
job.setNumReduceTasks(1);
job.setMapperClass(myMapper.class);
job.setInputFormatClass(myInputFormat.class);
job.setMapOutputKeyClass(DoubleWritable.class);
job.setMapOutputValueClass(Text.class); 
FileInputFormat.addInputPath(job, new Path(args[0]));
FileOutputFormat.setOutputPath(job, new Path(args[1]));

job.waitForCompletion(true);
}

}
