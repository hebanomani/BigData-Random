package custRecordReader;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, DoubleWritable, Text> {
	
	public void map(myKey k, myValue v, Context c) throws IOException, InterruptedException{
		// && v.getAmt()>=120.00 
		if(k.getUid().equals("4009719") && v.getAmt()>=120.00 ){
			c.write(new DoubleWritable(v.getAmt()), new Text(k.getUid() +" " +k.getTxndate()));
		}
		
	}

}
