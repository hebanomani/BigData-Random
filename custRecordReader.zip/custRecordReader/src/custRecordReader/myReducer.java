package custRecordReader;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<DoubleWritable,Text,Text, DoubleWritable>{
	public void reduce(DoubleWritable inp, Iterable<Text> out,Context c){
		
	}
	

}
