package custRecordReader;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

public class myRecordReader extends RecordReader<myKey, myValue>{
	
	myKey key;
	myValue value;
	private LineRecordReader read = new LineRecordReader();

	@Override
	public void close() throws IOException {
		read.close();
	}

	@Override
	public myKey getCurrentKey() throws IOException, InterruptedException {
		return key;
	}

	@Override
	public myValue getCurrentValue() throws IOException, InterruptedException {
		return value;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		return read.getProgress();
	}

	@Override
	public void initialize(InputSplit arg0, TaskAttemptContext arg1) throws IOException, InterruptedException {
		read.initialize(arg0, arg1);
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		
		boolean gotNextKeyValue = read.nextKeyValue();
		if(gotNextKeyValue){
			if(key==null){
				key = new myKey();
			}
			if(value == null){
				value = new myValue();
			}
			Text line = read.getCurrentValue();
			String[] tokens = line.toString().split(",");
			
			key.setTxnDate(new Text(tokens[1]));
			key.setuId(new Text(tokens[2]));
			value.setAmt(new Text(tokens[3]));
			
	}
	else
	{
		key = null;
		value = null;
	}
	return gotNextKeyValue;
	
	}
	}
