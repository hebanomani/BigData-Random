package custRecordReader;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class myKey implements WritableComparable{
	Text tDate, uId;
	
	public myKey(){
		this.tDate = new Text();
		this.uId = new Text();
	}
	public myKey(Text tDate,Text uId){
		this.tDate = tDate;
		this.uId = uId;		
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		tDate.readFields(arg0);
		uId.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		tDate.write(arg0);
		uId.write(arg0);
	}

	@Override
	public int compareTo(Object o) {
		myKey other = (myKey)o;
		
		int cmp = uId.compareTo(other.uId);
		if(cmp != 0){
				return cmp;
		}
		return cmp = tDate.compareTo(other.tDate);
		}
	
	public String getUid() {
		return uId.toString();
	}
	public void setuId(Text uId) {
		this.uId = uId;
	}
	public String getTxndate() {
		return tDate.toString();
	}
	public void setTxnDate(Text tDate) {
		this.tDate = tDate;
	}
	
	

}
