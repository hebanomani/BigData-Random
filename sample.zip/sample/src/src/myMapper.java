package src;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
 public void map(LongWritable inkey, Text inval, Context context) throws IOException, InterruptedException{
	 String line = inval.toString();
	//String name="Heba";
	 String[] lineparts = line.split(" ");
	 for (String singlevalue : lineparts){
		//if(singlevalue.equalsIgnoreCase(name)){
		 Text mapoutkey = new Text(singlevalue);
		 IntWritable mapoutval = new IntWritable(1);
		 context.write(mapoutkey, mapoutval);
		//}
	 }
 }
 
}
