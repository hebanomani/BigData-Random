package src;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myreducer extends Reducer<Text, IntWritable, Text, IntWritable>{
	public void reduce(Text inkey, Iterable<IntWritable> invals, Context context) throws IOException, InterruptedException{
		int count=0;
		//Text name=new Text("Heba");
		//if(inkey == name){
		for(IntWritable singlevalue: invals){
			count++;
		}
		//}
		context.write(inkey,new IntWritable(count));
	}

}
