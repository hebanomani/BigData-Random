package src;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class myPartitioner extends Partitioner<Text, IntWritable> {
	
	

	@Override
	public int getPartition(Text arg0, IntWritable arg1, int arg2) {
		// TODO Auto-generated method stub
		if(arg0.toString().toLowerCase().startsWith("a"))
			return 0;
		else if(arg0.toString().toLowerCase().startsWith("n"))
			return 1;
		else
			return 2;
	}

}
